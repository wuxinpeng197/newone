## Installing

```
$ npm install create-react-app -g
$ npm install
```

## Running The App

### DEV

on port 3000.

```
$ npm run start
```

### Production

on port 3001.

```
$ npm run build
$ node server/server.js
```
